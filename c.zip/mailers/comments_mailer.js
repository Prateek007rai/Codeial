const nodemailer = require('../config/nodemailer');




exports.newComent = (comment)=>{
    console.log('Inside comments mailer');

    nodeMailer.transporter.sendMail({
        from: 'prateekrai341036@gmail.com',                                                          // sender address
        to: comment.user.email,                                                      // list of receivers
        subject: "Hello ✔ , new Comment published",                                  // Subject line
        text: "Hello world?",                                                             // plain text body
        html: "<h1>Yup! , your comment is now published.</h1>",                         // html body
    }, 
    (err , info) =>{
        if(err){ console.log('error in sending mails '); return; }

        console.log('Message sent',info);
        return;
    });
}